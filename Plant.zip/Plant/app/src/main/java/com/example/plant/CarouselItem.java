package com.example.plant;

public class CarouselItem {

//    https://www.youtube.com/watch?v=iA9iqygq11Q
    private int image;

    CarouselItem(int image){
        this.image = image;
    }

    public int getImage(){
        return image;
    }
}
